//
//  ILHomeEventsCarouselView.swift
//  InnerLamp
//

import UIKit

/// Carousel "Sự kiện Phật giáo" ở Trang chủ: cuộn ngang từng thẻ tháng (mỗi thẻ liệt kê vài sự
/// kiện), chấm phân trang phía dưới. Riêng cho Trang chủ nên nằm ở `Scenes/Home`, không phải
/// component dùng chung (khác `events` — màn danh sách sự kiện đầy đủ, chưa có trong scope).
final class ILHomeEventsCarouselView: UIView {

    // MARK: - Layout constants
    /// Card rộng 84% khung carousel để lộ mép thẻ tháng kế bên (peek).
    private static let cardWidthRatio: CGFloat = 0.84
    private static let cardSpacing: CGFloat = 12
    /// Release velocity (points/ms) above which a swipe counts as a flick and pages in its direction.
    private static let flickVelocityThreshold: CGFloat = 0.2

    // MARK: - Properties
    var months: [ILHomeEventMonthModel] = [] {
        didSet { rebuildCards() }
    }

    var onEventTap: ((ILHomeEventItemModel) -> Void)?

    /// Chạm dòng "+N sự kiện khác" ở cuối thẻ tháng có hơn 3 sự kiện.
    var onMoreTap: (() -> Void)?

    /// Bề rộng 1 thẻ theo khung hiện tại; dùng chung cho cả lúc dựng thẻ lẫn lúc tính snap.
    private var cardWidth: CGFloat { (bounds.width * Self.cardWidthRatio).rounded(.down) }
    /// Khoảng cách giữa 2 mép trái liên tiếp = bề rộng thẻ + spacing.
    private var pageStride: CGFloat { cardWidth + Self.cardSpacing }

    // MARK: - UI Elements
    private lazy var scrollView: UIScrollView = {
        let v = UIScrollView()
        v.showsHorizontalScrollIndicator = false
        v.decelerationRate = .fast
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()
    private lazy var cardsStack: UIStackView = {
        let v = UIStackView()
        v.axis = .horizontal
        v.spacing = Self.cardSpacing
        v.alignment = .top
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()
    private lazy var dotsStack: UIStackView = {
        let v = UIStackView()
        v.axis = .horizontal
        v.spacing = 6
        v.alignment = .center
        v.distribution = .equalCentering
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()
    private var cardWidthConstraints: [NSLayoutConstraint] = []
    private var currentPage = 0

    // MARK: - Initializer
    init() {
        super.init(frame: .zero)
        setupViews()
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    // MARK: - Setup
    private func setupViews() {
        scrollView.delegate = self
        scrollView.addSubview(cardsStack)

        addSubview(scrollView)
        addSubview(dotsStack)

        NSLayoutConstraint.activate([
            scrollView.topAnchor.constraint(equalTo: topAnchor),
            scrollView.leadingAnchor.constraint(equalTo: leadingAnchor),
            scrollView.trailingAnchor.constraint(equalTo: trailingAnchor),

            cardsStack.topAnchor.constraint(equalTo: scrollView.contentLayoutGuide.topAnchor),
            cardsStack.bottomAnchor.constraint(equalTo: scrollView.contentLayoutGuide.bottomAnchor),
            cardsStack.leadingAnchor.constraint(equalTo: scrollView.contentLayoutGuide.leadingAnchor),
            cardsStack.trailingAnchor.constraint(equalTo: scrollView.contentLayoutGuide.trailingAnchor),
            cardsStack.heightAnchor.constraint(equalTo: scrollView.frameLayoutGuide.heightAnchor),

            dotsStack.topAnchor.constraint(equalTo: scrollView.bottomAnchor, constant: 11),
            dotsStack.centerXAnchor.constraint(equalTo: centerXAnchor),
            dotsStack.bottomAnchor.constraint(equalTo: bottomAnchor)
        ])
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        let width = cardWidth
        guard width > 0 else { return }
        // Inset phải đủ lớn để tháng cuối cũng snap được về mép trái (offset tối đa = (n-1) * pageStride).
        // Thiếu inset này thì trang cuối bị kẹp ở offset tối đa và lệch khỏi vị trí snap.
        scrollView.contentInset.right = max(0, bounds.width - width)
        for constraint in cardWidthConstraints where constraint.constant != width {
            constraint.constant = width
        }
    }

    private func rebuildCards() {
        cardsStack.arrangedSubviews.forEach {
            cardsStack.removeArrangedSubview($0)
            $0.removeFromSuperview()
        }
        cardWidthConstraints.removeAll()

        let width = max(cardWidth, 1)
        for month in months {
            let card = ILHomeEventMonthCardView(month: month)
            card.onEventTap = { [weak self] event in self?.onEventTap?(event) }
            card.onMoreTap = { [weak self] in self?.onMoreTap?() }
            let widthConstraint = card.widthAnchor.constraint(equalToConstant: width)
            widthConstraint.isActive = true
            cardWidthConstraints.append(widthConstraint)
            cardsStack.addArrangedSubview(card)
        }

        // Mở carousel ở thẻ tháng hiện tại (nếu có sự kiện), không phải luôn ở thẻ đầu tiên.
        currentPage = months.firstIndex(where: { $0.isCurrentMonth }) ?? 0
        // Ép layout ngay để `contentSize` khớp số thẻ vừa dựng trước khi set offset theo trang.
        layoutIfNeeded()
        scrollView.setContentOffset(CGPoint(x: CGFloat(currentPage) * pageStride, y: 0), animated: false)

        rebuildDots()
    }

    private func rebuildDots() {
        dotsStack.arrangedSubviews.forEach {
            dotsStack.removeArrangedSubview($0)
            $0.removeFromSuperview()
        }
        guard months.count > 1 else { return }
        for index in months.indices {
            let dot = UIView()
            dot.layer.cornerRadius = 2.5
            dot.translatesAutoresizingMaskIntoConstraints = false
            dot.widthAnchor.constraint(equalToConstant: index == currentPage ? 16 : 5).isActive = true
            dot.heightAnchor.constraint(equalToConstant: 5).isActive = true
            dot.backgroundColor = index == currentPage ? ILColors.goldDeep : ILColors.borderStrong
            dotsStack.addArrangedSubview(dot)
        }
    }
}

// MARK: - UIScrollViewDelegate
extension ILHomeEventsCarouselView: UIScrollViewDelegate {
    /// Snap one card per swipe. The target page is decided from the page the carousel was
    /// heading to (`currentPage`) plus the release velocity — not from the projected offset —
    /// so a short, fast flick always advances one page in the flick direction instead of
    /// snapping back against the finger (which caused the visible stutter).
    func scrollViewWillEndDragging(_ scrollView: UIScrollView, withVelocity velocity: CGPoint, targetContentOffset: UnsafeMutablePointer<CGPoint>) {
        let stride = pageStride
        guard stride > 0, !months.isEmpty else { return }
        let target: Int
        if velocity.x > Self.flickVelocityThreshold {
            target = currentPage + 1
        } else if velocity.x < -Self.flickVelocityThreshold {
            target = currentPage - 1
        } else {
            target = min(max(page(forOffset: scrollView.contentOffset.x), currentPage - 1), currentPage + 1)
        }
        let clamped = min(max(target, 0), months.count - 1)
        targetContentOffset.pointee = CGPoint(x: CGFloat(clamped) * stride, y: 0)
        guard clamped != currentPage else { return }
        currentPage = clamped
        rebuildDots()
    }

    /// Trang gần nhất ứng với `offset`, luôn kẹp trong khoảng thẻ hợp lệ.
    private func page(forOffset offset: CGFloat) -> Int {
        guard pageStride > 0, !months.isEmpty else { return 0 }
        let raw = Int((offset / pageStride).rounded())
        return min(max(raw, 0), months.count - 1)
    }
}

/// 1 thẻ tháng trong `ILHomeEventsCarouselView` — tiêu đề tháng + số sự kiện, danh sách sự kiện
/// (ngày/thứ + tiêu đề + nhãn âm lịch).
private final class ILHomeEventMonthCardView: UIView {

    var onEventTap: ((ILHomeEventItemModel) -> Void)?
    var onMoreTap: (() -> Void)?

    private let month: ILHomeEventMonthModel

    init(month: ILHomeEventMonthModel) {
        self.month = month
        super.init(frame: .zero)
        setupViews()
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    private func setupViews() {
        translatesAutoresizingMaskIntoConstraints = false
        backgroundColor = ILColors.surface
        layer.cornerRadius = ILMetrics.radiusCardSmall + 4
        layer.borderWidth = 1
        layer.borderColor = ILColors.border.cgColor

        let monthLabel = UILabel()
        monthLabel.font = ILTypography.bodySmallMedium
        monthLabel.textColor = ILColors.ink
        monthLabel.text = month.monthLabel

        let countLabel = UILabel()
        countLabel.font = ILTypography.caption
        countLabel.textColor = ILColors.inkMuted
        countLabel.text = String(format: "home.events.countFormat".localized, month.totalEventsCount)

        let headerRow = UIStackView(arrangedSubviews: [monthLabel, countLabel])
        headerRow.axis = .horizontal
        headerRow.distribution = .equalSpacing
        headerRow.alignment = .firstBaseline
        headerRow.translatesAutoresizingMaskIntoConstraints = false

        let eventsStack = UIStackView()
        eventsStack.axis = .vertical
        eventsStack.spacing = 0
        eventsStack.translatesAutoresizingMaskIntoConstraints = false

        for (index, event) in month.events.enumerated() {
            if index > 0 {
                let divider = UIView()
                divider.backgroundColor = ILColors.border
                divider.translatesAutoresizingMaskIntoConstraints = false
                divider.heightAnchor.constraint(equalToConstant: 1).isActive = true
                eventsStack.addArrangedSubview(divider)
            }
            let row = ILHomeEventRowView(event: event)
            row.onTap = { [weak self] in self?.onEventTap?(event) }
            eventsStack.addArrangedSubview(row)
        }

        // Thẻ chỉ liệt kê 3 sự kiện đầu — phần còn lại gộp thành dòng "+N sự kiện khác" (prototype
        // `hasMore`): vạch kẻ trên, chữ `link`, chạm mở màn Lịch lễ.
        let hiddenCount = month.totalEventsCount - month.events.count
        let moreRow: UIView? = hiddenCount > 0 ? makeMoreRow(hiddenCount: hiddenCount) : nil

        addSubview(headerRow)
        addSubview(eventsStack)
        if let moreRow { addSubview(moreRow) }

        NSLayoutConstraint.activate([
            headerRow.topAnchor.constraint(equalTo: topAnchor, constant: 16),
            headerRow.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 16),
            headerRow.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -16),

            eventsStack.topAnchor.constraint(equalTo: headerRow.bottomAnchor, constant: 10),
            eventsStack.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 16),
            eventsStack.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -16),
            eventsStack.bottomAnchor.constraint(
                equalTo: moreRow?.topAnchor ?? bottomAnchor,
                constant: moreRow == nil ? -14 : -8
            )
        ])
        if let moreRow {
            NSLayoutConstraint.activate([
                moreRow.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 16),
                moreRow.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -16),
                moreRow.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -14)
            ])
        }
        registerForTraitChanges([UITraitUserInterfaceStyle.self]) { (view: ILHomeEventMonthCardView, _) in
            view.applyColorAppearanceChange()
        }
    }

    private func applyColorAppearanceChange() {
        layer.borderColor = ILColors.border.cgColor
    }

    /// Dòng "+N sự kiện khác": vạch kẻ 1pt phía trên, đệm 10pt, chữ `bodySmallMedium` màu `link`.
    private func makeMoreRow(hiddenCount: Int) -> UIView {
        let container = UIView()
        container.translatesAutoresizingMaskIntoConstraints = false

        let divider = UIView()
        divider.backgroundColor = ILColors.border
        divider.translatesAutoresizingMaskIntoConstraints = false

        let label = UILabel()
        label.font = ILTypography.bodySmallMedium
        label.textColor = ILColors.link
        label.text = String(format: "home.events.moreFormat".localized, hiddenCount)
        label.translatesAutoresizingMaskIntoConstraints = false

        let control = UIControl()
        control.translatesAutoresizingMaskIntoConstraints = false
        control.addTarget(self, action: #selector(handleMoreTap), for: .touchUpInside)

        container.addSubview(divider)
        container.addSubview(label)
        container.addSubview(control)
        NSLayoutConstraint.activate([
            divider.topAnchor.constraint(equalTo: container.topAnchor),
            divider.leadingAnchor.constraint(equalTo: container.leadingAnchor),
            divider.trailingAnchor.constraint(equalTo: container.trailingAnchor),
            divider.heightAnchor.constraint(equalToConstant: 1),

            label.topAnchor.constraint(equalTo: divider.bottomAnchor, constant: 10),
            label.leadingAnchor.constraint(equalTo: container.leadingAnchor),
            label.trailingAnchor.constraint(lessThanOrEqualTo: container.trailingAnchor),
            label.bottomAnchor.constraint(equalTo: container.bottomAnchor),

            control.topAnchor.constraint(equalTo: container.topAnchor),
            control.leadingAnchor.constraint(equalTo: container.leadingAnchor),
            control.trailingAnchor.constraint(equalTo: container.trailingAnchor),
            control.bottomAnchor.constraint(equalTo: container.bottomAnchor)
        ])
        return container
    }

    @objc private func handleMoreTap() {
        onMoreTap?()
    }
}

/// 1 hàng sự kiện trong `ILHomeEventMonthCardView`.
private final class ILHomeEventRowView: UIView {

    var onTap: (() -> Void)?

    init(event: ILHomeEventItemModel) {
        super.init(frame: .zero)
        setupViews(event: event)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    private func setupViews(event: ILHomeEventItemModel) {
        translatesAutoresizingMaskIntoConstraints = false

        let dayLabel = UILabel()
        dayLabel.font = ILTypography.beVietnamPro(size: 16, weight: .medium)
        dayLabel.textColor = event.tone.accentColor
        dayLabel.text = event.dayNumber
        dayLabel.textAlignment = .center

        let weekdayLabel = UILabel()
        weekdayLabel.font = ILTypography.captionSmall
        weekdayLabel.textColor = ILColors.inkMuted
        weekdayLabel.text = event.weekdayLabel
        weekdayLabel.textAlignment = .center

        let dateColumn = UIStackView(arrangedSubviews: [dayLabel, weekdayLabel])
        dateColumn.axis = .vertical
        dateColumn.spacing = 2
        dateColumn.alignment = .center
        dateColumn.translatesAutoresizingMaskIntoConstraints = false
        dateColumn.widthAnchor.constraint(equalToConstant: 40).isActive = true

        let titleLabel = UILabel()
        titleLabel.font = ILTypography.body
        titleLabel.textColor = ILColors.ink
        titleLabel.text = event.title
        titleLabel.numberOfLines = 2

        let lunarLabel = UILabel()
        lunarLabel.font = ILTypography.caption
        lunarLabel.textColor = ILColors.inkTertiary
        lunarLabel.text = event.lunarLabel
        lunarLabel.numberOfLines = 1

        let textColumn = UIStackView(arrangedSubviews: [titleLabel, lunarLabel])
        textColumn.axis = .vertical
        textColumn.spacing = 3
        textColumn.translatesAutoresizingMaskIntoConstraints = false

        let row = UIStackView(arrangedSubviews: [dateColumn, textColumn])
        row.axis = .horizontal
        row.spacing = 12
        row.alignment = .center
        row.isUserInteractionEnabled = false
        row.translatesAutoresizingMaskIntoConstraints = false
        addSubview(row)

        let control = UIControl()
        control.translatesAutoresizingMaskIntoConstraints = false
        control.addTarget(self, action: #selector(handleTap), for: .touchUpInside)
        addSubview(control)

        NSLayoutConstraint.activate([
            row.topAnchor.constraint(equalTo: topAnchor, constant: 9),
            row.leadingAnchor.constraint(equalTo: leadingAnchor),
            row.trailingAnchor.constraint(equalTo: trailingAnchor),
            row.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -9),

            control.leadingAnchor.constraint(equalTo: leadingAnchor),
            control.trailingAnchor.constraint(equalTo: trailingAnchor),
            control.topAnchor.constraint(equalTo: topAnchor),
            control.bottomAnchor.constraint(equalTo: bottomAnchor)
        ])
    }

    @objc private func handleTap() {
        onTap?()
    }
}

/// Map `ILHomeEventTone` (Domain) sang màu accent hiển thị — chỉ dùng trong carousel sự kiện
/// nên đặt private ở đây, không chung với `ILColors.Tone` (vốn có thêm case `.ink` không khớp).
private extension ILHomeEventTone {
    var accentColor: UIColor {
        switch self {
        case .gold: return ILColors.goldDeep
        case .green: return ILColors.greenText
        case .rose: return ILColors.roseText
        }
    }
}
