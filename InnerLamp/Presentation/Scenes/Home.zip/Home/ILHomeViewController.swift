//
//  ILHomeViewController.swift
//  InnerLamp
//

import UIKit
import Combine

final class ILHomeViewController: BaseViewController {

    // MARK: - Properties
    private let viewModel: ILHomeViewModel
    private var cancellables = Set<AnyCancellable>()
    private let viewDidLoadSubject = PassthroughSubject<Void, Never>()
    private let malaFullscreenTappedSubject = PassthroughSubject<Void, Never>()
    private let lunarCalendarTappedSubject = PassthroughSubject<Void, Never>()
    private let memorialTappedSubject = PassthroughSubject<Void, Never>()
    private let lunarHeroTappedSubject = PassthroughSubject<Void, Never>()
    private let dayTappedSubject = PassthroughSubject<String, Never>()
    private let photosTappedSubject = PassthroughSubject<Void, Never>()
    private let bellTappedSubject = PassthroughSubject<Void, Never>()
    private let eventsTappedSubject = PassthroughSubject<Void, Never>()
    private let eventTappedSubject = PassthroughSubject<String, Never>()
    private let articleTappedSubject = PassthroughSubject<String, Never>()
    private let articlesViewAllTappedSubject = PassthroughSubject<Void, Never>()
    private let templeTappedSubject = PassthroughSubject<String, Never>()
    private let templesViewAllTappedSubject = PassthroughSubject<Void, Never>()
    private let deityTappedSubject = PassthroughSubject<String, Never>()
    private let deitiesViewAllTappedSubject = PassthroughSubject<Void, Never>()
    private let suggestedSessionTappedSubject = PassthroughSubject<String, Never>()
    private let notificationTappedSubject = PassthroughSubject<Void, Never>()
    private let avatarTappedSubject = PassthroughSubject<Void, Never>()

    // MARK: - UI Elements
    private lazy var scrollView: UIScrollView = {
        let v = UIScrollView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.showsVerticalScrollIndicator = false
        v.contentInsetAdjustmentBehavior = .never
        return v
    }()
    private lazy var contentView: UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()

    // Pinned greeting header: sits above the scroll view and blurs in as content scrolls under it.
    private lazy var headerContainer: ILStickyHeaderBand = ILStickyHeaderBand(tintColor: ILColors.canvasWarm)
    private lazy var headerView: ILHomeGreetingHeaderView = {
        let v = ILHomeGreetingHeaderView()
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()
    private var lastHeaderHeight: CGFloat = 0
    private lazy var weekCalendarView: ILHomeWeekCalendarView = {
        let v = ILHomeWeekCalendarView()
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()
    private lazy var lunarHeroCard: ILHomeLunarHeroCardView = {
        let v = ILHomeLunarHeroCardView()
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()

    private lazy var eventsHeader: ILSectionHeaderView = {
        let v = ILSectionHeaderView(title: "home.events.title".localized, trailingText: "home.events.viewAll".localized, icon: ILIcons.homeEvent, iconTone: .rose)
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()
    private lazy var eventsCarousel: ILHomeEventsCarouselView = {
        let v = ILHomeEventsCarouselView()
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()

    private lazy var photosHeader: ILSectionHeaderView = {
        let v = ILSectionHeaderView(title: "home.photos.title".localized, trailingText: "home.photos.viewAll".localized, icon: ILIcons.homePhoto, iconTone: .rose)
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()
    private lazy var photosGrid: ILHomePhotoGridView = {
        let v = ILHomePhotoGridView()
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()

    private lazy var templesHeader: ILSectionHeaderView = {
        let v = ILSectionHeaderView(title: "home.temple.title".localized, trailingText: "home.temple.find".localized, icon: ILIcons.homeTemple, iconTone: .gold)
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()
    private lazy var templesCarousel: ILHomeTempleCarouselView = {
        let v = ILHomeTempleCarouselView()
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()

    private lazy var deitiesHeader: ILSectionHeaderView = {
        let v = ILSectionHeaderView(title: "home.deity.title".localized, trailingText: "home.deity.viewAll".localized, icon: ILIcons.homeBuddha, iconTone: .gold)
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()
    private lazy var deitiesCarousel: ILHomeDeityCarouselView = {
        let v = ILHomeDeityCarouselView()
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()

    private lazy var todayCard: ILStatProgressCardView = ILStatProgressCardView(title: "home.today.title".localized)
    private lazy var streakCard: ILStatStreakCardView = ILStatStreakCardView(title: "home.streak.title".localized, unitText: "home.streak.unit".localized)
    private lazy var statsStack: UIStackView = {
        let v = UIStackView()
        v.addArrangedSubview(todayCard)
        v.addArrangedSubview(streakCard)
        v.axis = .horizontal
        v.spacing = ILMetrics.rowSpacing
        v.distribution = .fillEqually
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()

    private lazy var malaHeader: ILSectionHeaderView = {
        let v = ILSectionHeaderView(title: "home.mala.title".localized, trailingText: "home.mala.fullscreen".localized, icon: ILIcons.homeBeads, iconTone: .rose)
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()
    private lazy var malaCounter: ILMalaCounterView = {
        let v = ILMalaCounterView()
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()

    private lazy var bellCard: ILHomeBellCardView = {
        let v = ILHomeBellCardView()
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()

    private lazy var suggestedHeader: ILSectionHeaderView = {
        let v = ILSectionHeaderView(title: "home.suggested.title".localized, icon: ILIcons.homeSchedule, iconTone: .green)
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()
    private lazy var suggestedStack: UIStackView = {
        let v = UIStackView()
        v.axis = .vertical
        v.spacing = ILMetrics.rowSpacing
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()

    private lazy var articlesHeader: ILSectionHeaderView = {
        let v = ILSectionHeaderView(title: "home.article.title".localized, trailingText: "home.article.library".localized, icon: ILIcons.homeArticle, iconTone: .green)
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()
    private lazy var articlesList: ILHomeArticleListView = {
        let v = ILHomeArticleListView()
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()


    // MARK: - Initializer
    init(viewModel: ILHomeViewModel) {
        self.viewModel = viewModel
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    // MARK: - Lifecycle
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: animated)
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        lunarHeroCard.playRollAnimation()
    }

    /// Above-the-fold layers, top to bottom: lower ones slide further (20 → 40pt) and land later.
    override func entranceAnimationTargets() -> [UIView] {
        [headerView, weekCalendarView, lunarHeroCard, eventsHeader, eventsCarousel]
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        updateScrollInsetForHeader()
    }

    // MARK: - Setup
    override func setupViews() {
        super.setupViews()
        view.backgroundColor = ILColors.canvasWarm

        view.addSubview(scrollView)

        headerContainer.bind(to: scrollView)
        headerContainer.addSubview(headerView)
        view.addSubview(headerContainer)

        scrollView.addSubview(contentView)

        headerView.onNotificationTap = { [weak self] in self?.handleNotificationTapped() }
        headerView.onAvatarTap = { [weak self] in self?.handleAvatarTapped() }

        weekCalendarView.onCalendarLinkTap = { [weak self] in self?.handleCalendarLinkTapped() }
        weekCalendarView.onMemorialLinkTap = { [weak self] in self?.memorialTappedSubject.send(()) }
        weekCalendarView.onSelectDay = { [weak self] day in self?.dayTappedSubject.send(day.id) }

        lunarHeroCard.onTap = { [weak self] in self?.handleLunarHeroTapped() }

        eventsHeader.onTrailingTap = { [weak self] in self?.handleEventsViewAllTapped() }

        eventsCarousel.onEventTap = { [weak self] event in self?.handleEventTapped(event) }
        eventsCarousel.onMoreTap = { [weak self] in self?.handleEventsViewAllTapped() }

        photosHeader.onTrailingTap = { [weak self] in self?.handlePhotosViewAllTapped() }

        photosGrid.onTap = { [weak self] in self?.handlePhotoTapped() }

        templesHeader.onTrailingTap = { [weak self] in self?.handleTemplesViewAllTapped() }

        templesCarousel.onTempleTap = { [weak self] temple in self?.handleTempleTapped(temple) }

        deitiesHeader.onTrailingTap = { [weak self] in self?.handleDeitiesViewAllTapped() }

        deitiesCarousel.onDeityTap = { [weak self] deity in self?.handleDeityTapped(deity) }

        malaHeader.onTrailingTap = { [weak self] in self?.handleMalaFullscreenTapped() }

        malaCounter.onTap = { [weak self] in self?.handleMalaFullscreenTapped() }

        bellCard.onTap = { [weak self] in self?.handleBellTapped() }

        articlesHeader.onTrailingTap = { [weak self] in self?.handleArticlesViewAllTapped() }

        articlesList.onArticleTap = { [weak self] article in self?.handleArticleTapped(article) }

        [
            weekCalendarView, lunarHeroCard, eventsHeader, eventsCarousel,
            photosHeader, photosGrid, templesHeader, templesCarousel, deitiesHeader, deitiesCarousel,
            statsStack,
            malaHeader, malaCounter, bellCard, suggestedHeader, suggestedStack,
            articlesHeader, articlesList
        ].forEach {
            contentView.addSubview($0)
        }
    }

    override func setupConstraints() {
        super.setupConstraints()

        NSLayoutConstraint.activate([
            scrollView.topAnchor.constraint(equalTo: view.topAnchor),
            scrollView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            scrollView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            scrollView.bottomAnchor.constraint(equalTo: view.bottomAnchor),

            contentView.topAnchor.constraint(equalTo: scrollView.topAnchor),
            contentView.leadingAnchor.constraint(equalTo: scrollView.leadingAnchor, constant: ILMetrics.screenHorizontal),
            contentView.trailingAnchor.constraint(equalTo: scrollView.trailingAnchor, constant: -ILMetrics.screenHorizontal),
            contentView.bottomAnchor.constraint(equalTo: scrollView.bottomAnchor, constant: -ILMetrics.bottomNavHeight),
            contentView.widthAnchor.constraint(equalTo: scrollView.widthAnchor, constant: -ILMetrics.screenHorizontal * 2),

            headerContainer.topAnchor.constraint(equalTo: view.topAnchor),
            headerContainer.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            headerContainer.trailingAnchor.constraint(equalTo: view.trailingAnchor),

            headerView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: ILMetrics.spaceMedium),
            headerView.leadingAnchor.constraint(equalTo: headerContainer.leadingAnchor, constant: ILMetrics.screenHorizontal),
            headerView.trailingAnchor.constraint(equalTo: headerContainer.trailingAnchor, constant: -ILMetrics.screenHorizontal),
            headerView.bottomAnchor.constraint(equalTo: headerContainer.bottomAnchor, constant: -ILMetrics.rowSpacing),

            weekCalendarView.topAnchor.constraint(equalTo: contentView.topAnchor),
            weekCalendarView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            weekCalendarView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),

            lunarHeroCard.topAnchor.constraint(equalTo: weekCalendarView.bottomAnchor, constant: ILMetrics.groupSpacing - 2),
            lunarHeroCard.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            lunarHeroCard.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),

            eventsHeader.topAnchor.constraint(equalTo: lunarHeroCard.bottomAnchor, constant: ILMetrics.groupSpacing),
            eventsHeader.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            eventsHeader.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),

            eventsCarousel.topAnchor.constraint(equalTo: eventsHeader.bottomAnchor, constant: ILMetrics.rowSpacing),
            eventsCarousel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            eventsCarousel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),

            photosHeader.topAnchor.constraint(equalTo: eventsCarousel.bottomAnchor, constant: ILMetrics.groupSpacing),
            photosHeader.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            photosHeader.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),

            photosGrid.topAnchor.constraint(equalTo: photosHeader.bottomAnchor, constant: ILMetrics.rowSpacing),
            photosGrid.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            photosGrid.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),

            templesHeader.topAnchor.constraint(equalTo: photosGrid.bottomAnchor, constant: ILMetrics.groupSpacing),
            templesHeader.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            templesHeader.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),

            templesCarousel.topAnchor.constraint(equalTo: templesHeader.bottomAnchor, constant: ILMetrics.rowSpacing),
            templesCarousel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            templesCarousel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),

            deitiesHeader.topAnchor.constraint(equalTo: templesCarousel.bottomAnchor, constant: ILMetrics.groupSpacing),
            deitiesHeader.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            deitiesHeader.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),

            deitiesCarousel.topAnchor.constraint(equalTo: deitiesHeader.bottomAnchor, constant: ILMetrics.rowSpacing),
            deitiesCarousel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            deitiesCarousel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),

            statsStack.topAnchor.constraint(equalTo: deitiesCarousel.bottomAnchor, constant: ILMetrics.groupSpacing),
            statsStack.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            statsStack.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),

            malaHeader.topAnchor.constraint(equalTo: statsStack.bottomAnchor, constant: ILMetrics.groupSpacing),
            malaHeader.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            malaHeader.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),

            malaCounter.topAnchor.constraint(equalTo: malaHeader.bottomAnchor, constant: ILMetrics.rowSpacing),
            malaCounter.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            malaCounter.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),

            bellCard.topAnchor.constraint(equalTo: malaCounter.bottomAnchor, constant: ILMetrics.rowSpacing),
            bellCard.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            bellCard.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),

            suggestedHeader.topAnchor.constraint(equalTo: bellCard.bottomAnchor, constant: ILMetrics.groupSpacing),
            suggestedHeader.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            suggestedHeader.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),

            suggestedStack.topAnchor.constraint(equalTo: suggestedHeader.bottomAnchor, constant: ILMetrics.rowSpacing),
            suggestedStack.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            suggestedStack.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),

            articlesHeader.topAnchor.constraint(equalTo: suggestedStack.bottomAnchor, constant: ILMetrics.groupSpacing),
            articlesHeader.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            articlesHeader.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),

            articlesList.topAnchor.constraint(equalTo: articlesHeader.bottomAnchor, constant: ILMetrics.rowSpacing),
            articlesList.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            articlesList.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),
            articlesList.bottomAnchor.constraint(equalTo: contentView.bottomAnchor)
        ])
    }

    override func bindViewModel() {
        super.bindViewModel()

        let input = ILHomeViewModel.Input(
            viewDidLoad: viewDidLoadSubject.eraseToAnyPublisher(),
            malaFullscreenTapped: malaFullscreenTappedSubject.eraseToAnyPublisher(),
            lunarCalendarTapped: lunarCalendarTappedSubject.eraseToAnyPublisher(),
            memorialTapped: memorialTappedSubject.eraseToAnyPublisher(),
            lunarHeroTapped: lunarHeroTappedSubject.eraseToAnyPublisher(),
            dayTapped: dayTappedSubject.eraseToAnyPublisher(),
            photosTapped: photosTappedSubject.eraseToAnyPublisher(),
            bellTapped: bellTappedSubject.eraseToAnyPublisher(),
            eventsTapped: eventsTappedSubject.eraseToAnyPublisher(),
            eventTapped: eventTappedSubject.eraseToAnyPublisher(),
            articleTapped: articleTappedSubject.eraseToAnyPublisher(),
            articlesViewAllTapped: articlesViewAllTappedSubject.eraseToAnyPublisher(),
            templeTapped: templeTappedSubject.eraseToAnyPublisher(),
            templesViewAllTapped: templesViewAllTappedSubject.eraseToAnyPublisher(),
            deityTapped: deityTappedSubject.eraseToAnyPublisher(),
            deitiesViewAllTapped: deitiesViewAllTappedSubject.eraseToAnyPublisher(),
            suggestedSessionTapped: suggestedSessionTappedSubject.eraseToAnyPublisher(),
            notificationTapped: notificationTappedSubject.eraseToAnyPublisher(),
            avatarTapped: avatarTappedSubject.eraseToAnyPublisher()
        )
        let output = viewModel.transform(input: input)

        // No `.receive(on: DispatchQueue.main)`: state is already sent on main (MainActor default),
        // and deferring it renders the first state only after the appear transition has run.
        output.state
            .sink { [weak self] state in self?.render(state: state) }
            .store(in: &cancellables)

        viewDidLoadSubject.send(())
    }

    // MARK: - Pinned header
    /// Content starts below the pinned header: reserve its height (+ the former gap) as top inset.
    private func updateScrollInsetForHeader() {
        let height = headerContainer.frame.height
        guard height > 0, height != lastHeaderHeight else { return }
        let isInitial = lastHeaderHeight == 0
        lastHeaderHeight = height
        scrollView.contentInset.top = height
        scrollView.verticalScrollIndicatorInsets.top = height
        if isInitial { scrollView.contentOffset.y = -height }
    }

    // MARK: - Render
    private func render(state: ViewState<ILHomeStateModel>) {
        switch state {
        case .idle, .loading:
            break
        case .success(let model):
            updateUI(with: model)
        case .failure(let error):
            showError(error.localizedDescription)
        }
    }

    private func updateUI(with model: ILHomeStateModel) {
        headerView.greetingText = model.greetingText
        headerView.dateText = model.dateText
        headerView.avatarInitial = model.avatarInitial

        weekCalendarView.weekdayLabels = model.weekdayLabels
        weekCalendarView.memorialLinkText = model.weekMemorialLinkText
        weekCalendarView.calendarLinkText = model.weekCalendarLinkText
        weekCalendarView.legend = model.weekLegend
        weekCalendarView.pages = model.weekPages

        lunarHeroCard.eyebrowText = model.lunarHero.eyebrowText
        lunarHeroCard.solarLabel = model.lunarHero.solarLabel
        lunarHeroCard.lunarDay = model.lunarHero.lunarDay
        lunarHeroCard.lunarMonthLabel = model.lunarHero.lunarMonthLabel
        lunarHeroCard.lunarYearLabel = model.lunarHero.lunarYearLabel
        lunarHeroCard.verseLines = model.lunarHero.verseLines
        lunarHeroCard.verseSource = model.lunarHero.verseSource
        lunarHeroCard.imageURL = model.lunarHero.imageURL
        lunarHeroCard.imageCreditText = model.lunarHero.imageCreditText

        eventsHeader.title = model.eventsTitle
        eventsHeader.trailingText = model.eventsViewAllText
        eventsCarousel.months = model.eventMonths

        todayCard.valueText = String(format: "home.today.valueFormat".localized, model.sessionMinutesDone, model.sessionMinutesGoal)
        todayCard.progress = model.sessionProgress

        streakCard.valueText = "\(model.streakDays)"
        streakCard.weekProgress = model.streakWeekProgress

        malaCounter.count = model.malaCount
        malaCounter.goal = model.malaGoal
        malaCounter.goalText = String(format: "home.mala.goalFormat".localized, model.malaGoal)
        malaCounter.mantraText = model.malaMantraText
        malaCounter.helperText = model.malaHelperText

        renderSuggestedSessions(model.suggestedSessions)

        photosHeader.title = model.photosTitle
        photosHeader.trailingText = model.photosViewAllText
        photosGrid.photos = model.photos
        photosGrid.photosMoreText = model.photosMoreText
        photosGrid.photosMoreLabel = model.photosMoreLabel

        templesHeader.title = model.templesTitle
        templesHeader.trailingText = model.templesFindText
        templesCarousel.temples = model.temples
        templesCarousel.emptyText = model.templesEmptyText
        templesCarousel.isLoading = model.templesLoading

        deitiesHeader.title = model.deitiesTitle
        deitiesHeader.trailingText = model.deitiesViewAllText
        deitiesCarousel.deities = model.deities
        deitiesCarousel.emptyText = model.deitiesEmptyText
        deitiesCarousel.isLoading = model.deitiesLoading

        bellCard.title = model.bellTitle
        bellCard.subtitle = model.bellSubtitle

        articlesHeader.title = model.articlesTitle
        articlesHeader.trailingText = model.articlesViewAllText
        articlesList.articles = model.articles
        articlesList.emptyText = model.articlesEmptyText
        articlesList.emptyMessage = "home.article.updating.message".localized
        articlesList.isLoading = model.articlesLoading
    }

    private func renderSuggestedSessions(_ sessions: [ILHomeSuggestedSessionModel]) {
        suggestedStack.arrangedSubviews.forEach {
            suggestedStack.removeArrangedSubview($0)
            $0.removeFromSuperview()
        }

        for session in sessions {
            let row = ILRow(
                title: session.title,
                subtitle: session.subtitle,
                trailingText: session.trailingText,
                tone: mapTone(session.tone),
                glyph: mapGlyph(session.glyph)
            )
            row.onTap = { [weak self] in self?.handleSuggestedSessionTapped(session) }
            suggestedStack.addArrangedSubview(row)
        }
    }

    private func mapTone(_ tone: ILHomeSessionTone) -> ILColors.Tone {
        switch tone {
        case .gold: return .gold
        case .green: return .green
        case .rose: return .rose
        case .ink: return .ink
        }
    }

    private func mapGlyph(_ glyph: ILHomeSessionGlyph) -> ILRow.Glyph {
        switch glyph {
        case .leaf: return .leaf
        case .book: return .book
        case .circle: return .circle
        case .dot: return .dot
        }
    }

    // MARK: - Actions
    private func handleNotificationTapped() {
        notificationTappedSubject.send(())
    }

    private func handleAvatarTapped() {
        avatarTappedSubject.send(())
    }

    private func handleCalendarLinkTapped() {
        lunarCalendarTappedSubject.send(())
    }

    private func handleLunarHeroTapped() {
        lunarHeroTappedSubject.send(())
    }

    /// Nút "Tất cả" ở mục "Sự kiện Phật giáo" — mở màn Lịch lễ Phật giáo (`festivals`).
    private func handleEventsViewAllTapped() {
        eventsTappedSubject.send(())
    }

    /// Chạm 1 sự kiện trong carousel "Sự kiện Phật giáo" — mở màn Chi tiết ngày lễ.
    private func handleEventTapped(_ event: ILHomeEventItemModel) {
        eventTappedSubject.send(event.id)
    }

    private func handleMalaFullscreenTapped() {
        malaFullscreenTappedSubject.send(())
    }

    /// 1 hàng "Thời khóa gợi ý" — ViewModel quyết định màn đích theo loại mục (thiền → Chuẩn bị
    /// thiền).
    private func handleSuggestedSessionTapped(_ session: ILHomeSuggestedSessionModel) {
        suggestedSessionTappedSubject.send(session.id)
    }

    /// Khối "Ảnh chùa đẹp" — mở màn gallery ảnh chùa (`photos`).
    private func handlePhotosViewAllTapped() {
        photosTappedSubject.send(())
    }

    private func handlePhotoTapped() {
        photosTappedSubject.send(())
    }

    /// Link "Xem tất cả" ở carousel "Chùa Việt Nam" — mở màn "Tất cả chùa".
    private func handleTemplesViewAllTapped() {
        templesViewAllTappedSubject.send(())
    }

    /// Chi tiết 1 chùa trong carousel "Chùa Việt Nam" — mở màn Trang chùa (`temple`) theo
    /// `temple.id`.
    private func handleTempleTapped(_ temple: ILHomeTempleModel) {
        templeTappedSubject.send(temple.id)
    }

    /// Chi tiết 1 vị Phật / Bồ Tát trong carousel "Thư viện Phật & Bồ Tát" — mở màn chi tiết
    /// (`deity`) theo `deity.id`.
    private func handleDeityTapped(_ deity: ILHomeDeityModel) {
        deityTappedSubject.send(deity.id)
    }

    /// Link "Xem tất cả" ở carousel "Thư viện Phật & Bồ Tát" — mở màn danh sách "Chư Phật & Bồ Tát".
    private func handleDeitiesViewAllTapped() {
        deitiesViewAllTappedSubject.send(())
    }

    /// Thẻ "Chuông mõ" — mở màn Chuông mõ.
    private func handleBellTapped() {
        bellTappedSubject.send(())
    }

    /// Link "Xem tất cả" ở mục "Bài viết Phật pháp hay" — mở màn Tất cả bài viết (`articles`).
    private func handleArticlesViewAllTapped() {
        articlesViewAllTappedSubject.send(())
    }

    /// Chi tiết 1 bài viết — mở màn Bài viết Phật pháp (`article`) theo `article.id`.
    private func handleArticleTapped(_ article: ILHomeArticleModel) {
        articleTappedSubject.send(article.id)
    }
}
